const mongoose = require("mongoose");

var mongoURL= 'mongodb+srv://kirtiman:7844031985@cluster0.d3kdjhx.mongodb.net/?retryWrites=true&w=majority'

mongoose.connect(mongoURL , {
    useUnifiedTopology : true ,
    useNewUrlParser : true 
})

var connection = mongoose.connection;

connection.on('error',()=>{
    console.log('Connection failed');
})
connection.on('connected',()=>{
    console.log('Connection successful');
})
